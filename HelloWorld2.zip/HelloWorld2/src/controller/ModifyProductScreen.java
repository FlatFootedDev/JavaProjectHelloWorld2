package controller;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import main.HelperValidation;
import model.Inventory;
import model.Part;
import model.Product;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class ModifyProductScreen implements Initializable {

    public TextField idTextField;
    public TextField nameTextField;
    public TextField inventoryTextField;
    public TextField minTextField;
    public TextField priceCostTextField;
    public TextField maxTextField;
    public TableView<Part> partsTable;
    public TableColumn partIdCol;
    public TableColumn partNameCol;
    public TableColumn partInvCol;
    public TableColumn partPriceCol;
    public TableView<Part> associatedPartsTable;
    public TableColumn associatedPartIdCol;
    public TableColumn associatedPartNameCol;
    public TableColumn associatedPartInvCol;
    public TableColumn associatedPartPriceCol;
    public TextField partSearch;
    public TextField searchTextField;

    private ObservableList<Part> associateParts = FXCollections.observableArrayList();
    private static Product modifiedProduct;

    /**
     * Initializes the ModifyProductScreen controller class.
     *
     * @param location NOT USED
     * @param resources NOT USED
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        partsTable.setItems(Inventory.getAllParts());
        partIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        partNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        partInvCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        partPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));

        associatedPartsTable.setItems(associateParts);
        associatedPartIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        associatedPartNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        associatedPartInvCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        associatedPartPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));

        idTextField.setText(String.valueOf(modifiedProduct.getId()));
        nameTextField.setText(modifiedProduct.getName());
        inventoryTextField.setText(String.valueOf(modifiedProduct.getStock()));
        priceCostTextField.setText(String.valueOf(modifiedProduct.getPrice()));
        minTextField.setText(String.valueOf(modifiedProduct.getMin()));
        maxTextField.setText(String.valueOf(modifiedProduct.getMax()));
        for (Part part : modifiedProduct.getAllAssociatedParts()) {
            associateParts.add(part);
        }
    }

    /**
     * Cancel - Returns to the current form.
     *
     * @param event Event when pressed returns to the current form.
     * @throws IOException Thrown when there is an error loading the screen.
     */
    public void onCancel(ActionEvent event) throws IOException {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.initModality(Modality.NONE);
        alert.setTitle("Add Part Exit");
        alert.setContentText("Would You Like to Cancel");
        Optional<ButtonType> cancel = alert.showAndWait();

        if (cancel.get() == ButtonType.OK) {
            Parent cancelPartAdd = FXMLLoader.load(getClass().getResource("/view/FirstInventoryScreen.fxml"));
            Scene scene = new Scene(cancelPartAdd);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            ;
            stage.show();
        } else {
            System.out.println("You clicked cancel");
        }

    }

    /**
     * Saves the newly Modified Product.
     *
     * @param event Event caused by clicking the save button on the form.
     */
    public void onSave(ActionEvent event) {

        try {


            int min = HelperValidation.getMinNum(minTextField.getText());
            int max = HelperValidation.getMaxNum(maxTextField.getText());
            double price = HelperValidation.getPrice(priceCostTextField.getText());
            String name = HelperValidation.getName(nameTextField.getText());
            int inv = HelperValidation.getStock(inventoryTextField.getText());
            HelperValidation.validateMinMaxStock(min, max, inv);
            int index = Inventory.getAllProducts().indexOf(modifiedProduct);
            Product product = new Product(modifiedProduct.getId(), name, price, inv, min, max);
            for (Part part : associateParts) {
                product.addAssociatedPart(part);
            }
            Inventory.updateProduct(index, product);

            Parent root = FXMLLoader.load(getClass().getResource("/view/FirstInventoryScreen.fxml"));
            Stage stage = (Stage) nameTextField.getScene().getWindow();
            stage.setTitle("Inventory Management Program");
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();

        } catch (NumberFormatException | IOException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Add Part Error");
            alert.setContentText(e.getMessage());
            alert.show();
            return;
        }

    }

    /**
     * Removes Associated Product.
     *
     * @param event Event when pressed - Removes associated Part from Product selected.
     */
    public void onRemove(ActionEvent event) {
        Part part = associatedPartsTable.getSelectionModel().getSelectedItem();

        if (part != null) {
            associateParts.remove(part);
        } else {
            Alert noPartSelected = new Alert(Alert.AlertType.ERROR);
            noPartSelected.setContentText("No Part Selected.\n Please try again.");
            noPartSelected.show();
        }
    }

    /**
     * Adds associated Part to Product.
     *
     * @param event Event when pressed adds associated Part to Product.
     */
    public void onAdd(ActionEvent event) {
        Part part = partsTable.getSelectionModel().getSelectedItem();

        if (part != null) {
            associateParts.add(part);
        } else {
            Alert noPartSelected = new Alert(Alert.AlertType.ERROR);
            noPartSelected.setContentText("No Part Selected.\n Please try again.");
            noPartSelected.show();
        }

    }

    /**
     * Saves newly Modified Product.
     *
     * @param event Event caused by hitting the enter key in the search field.
     */
    public void onSearch(ActionEvent event) {
        String searchItem = searchTextField.getText();
        if (searchItem.isBlank()) {
            partsTable.setItems(Inventory.getAllParts());
            return;
        }
        // search by ID
        try {
            Part part = Inventory.lookupPart(Integer.parseInt(searchItem));
            if (part == null) {

                throw new NumberFormatException();
            }
            //Highlights the found part--
            partsTable.getSelectionModel().select(part);
        } catch (NumberFormatException e) {
            //Search by name if not found by ID
            ObservableList<Part> list = Inventory.lookupPart(searchItem);
            if (list.size() > 0) {
                partsTable.setItems(list);
            } else {
                //Alert Box when no matches are found
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("PART SEARCHED");
                alert.setContentText("No Matches Found!");
                alert.show();

            }
        }

    }

    /**
     * Receives Product to be Modified from the Main Form.
     *
     * @param product Product to be Modified.
     */
    public static void recievedProduct(Product product) {
        modifiedProduct = product;

    }
}
