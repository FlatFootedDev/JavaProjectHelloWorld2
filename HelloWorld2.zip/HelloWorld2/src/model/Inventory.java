package model;


//Dependent to both Part and Products


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * @author George Calderon
 */
public class Inventory {
    private static ObservableList<Part> allParts = FXCollections.observableArrayList();
    private static ObservableList<Product> allProducts = FXCollections.observableArrayList();

    private static int partID = 1;
    private static int productID = 1;

    public static int getPartID() {
        return partID++;
    }

    public static int getProductID() {
        return productID++;
    }

    //UML Check - check
    public static void addPart(Part newPart) {
        allParts.add(newPart);
    }

    //UML Check - check
    public static void addProduct(Product newProduct) {
        allProducts.add(newProduct);
    }

    //UML Check
    public static Part lookupPart(int partId) {
        for (Part part : allParts) {
            if (part.getId() == partId) {
                return part;
            }
        }
        return null;
    }

    //UML Check
    public static Product lookupProduct(int productId) {
        for (Product product : allProducts) {
            if (product.getId() == productId) {
                return product;
            }
        }
        return null;
    }

    //UML Check
    public static ObservableList<Part> lookupPart(String partName) {
        ObservableList<Part> list = FXCollections.observableArrayList();
        for (Part part : allParts) {
            if (part.getName().toLowerCase().contains(partName.toLowerCase())) {
                list.add(part);
            }
        }

        return list;
    }

    //UML Check
    public static ObservableList<Product> lookupProduct(String productName) {
        ObservableList<Product> list = FXCollections.observableArrayList();
        for (Product product : allProducts) {
            if (product.getName().toLowerCase().contains(productName.toLowerCase())) {
                list.add(product);
            }
        }
        return list;
    }

    //UML Check
    public static void updatePart(int index, Part selectedPart) {
        allParts.set(index, selectedPart);


    }

    //UML Check
    public static void updateProduct(int index, Product newProduct) {
        allProducts.set(index, newProduct);


    }

    //UML Check
    public static boolean deletePart(Part selectedPart) {

        return allParts.remove(selectedPart);

    }

    //UML Check
    public static boolean deleteProduct(Product selectedProduct) {
        return allProducts.remove(selectedProduct);
    }

    //UML Check
    public static ObservableList<Part> getAllParts() {
        return allParts;
    }

    //UML Check
    public static ObservableList<Product> getAllProducts() {
        return allProducts;
    }

}
