package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Modality;
import javafx.stage.Stage;
import main.HelperValidation;
import model.InHouse;
import model.Inventory;
import model.Outsourced;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * Controller that Manages AddPart Form.
 *
 * @author George Calderon
 */
public class AddPartScreen implements Initializable {

    @FXML
    private Label machineCompanyLabel;
    @FXML
    private TextField partIdTextField;
    @FXML
    private TextField nameTextField;
    @FXML
    private TextField inventoryTextField;
    @FXML
    private TextField priceCostTextField;
    @FXML
    private TextField minTextField;
    @FXML
    private TextField maxTextField;
    @FXML
    private TextField machineCompanyText;
    @FXML
    private RadioButton outSourcedRadio;
    @FXML
    private RadioButton inHouseRadio;


    /**
     * Initializes Add Part controller class.
     *
     * @param location  NOT USED.
     * @param resources NOT USED.
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {


    }


    /**
     * Saves the new Part. <p>
     * RUNTIME ERROR: Exception when clicking Save Button - Caused by error in form path<p>
     * Resolved by correcting path to the form "/view/FirstInventoryScreen.fxml".
     *
     * @param event Event caused by clicking the save button on the form.
     */
    public void onSaveButton(ActionEvent event) {
        try {


            int min = HelperValidation.getMinNum(minTextField.getText());
            int max = HelperValidation.getMaxNum(maxTextField.getText());
            double price = HelperValidation.getPrice(priceCostTextField.getText());
            String name = HelperValidation.getName(nameTextField.getText());
            int inv = HelperValidation.getStock(inventoryTextField.getText());
            HelperValidation.validateMinMaxStock(min, max, inv);
            if (inHouseRadio.isSelected()) {
                int machId = HelperValidation.getMachineID(machineCompanyText.getText());
                Inventory.addPart(new InHouse(Inventory.getPartID(), name, price, inv, min, max, machId));
            } else {
                String company = HelperValidation.getCompanyName(machineCompanyText.getText());
                Inventory.addPart(new Outsourced(Inventory.getPartID(), name, price, inv, min, max, company));

            }

            Parent root = FXMLLoader.load(getClass().getResource("/view/FirstInventoryScreen.fxml"));
            Stage stage = (Stage) nameTextField.getScene().getWindow();
            stage.setTitle("Inventory Management Program");
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();

        } catch (NumberFormatException | IOException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Add Part Error");
            alert.setContentText(e.getMessage());
            alert.show();
            return;
        }
    }

    /**
     * Cancel form - returns to current form.
     *
     * @param event Event caused by user clicking cancel button.
     * @throws IOException - Thrown when there is an error loading form.
     */
    public void onCancelButton(ActionEvent event) throws IOException {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.initModality(Modality.NONE);
        alert.setTitle("Add Part Exit");
        alert.setContentText("Would You Like to Cancel");
        Optional<ButtonType> cancel = alert.showAndWait();

        if (cancel.get() == ButtonType.OK) {
            Parent cancelPartAdd = FXMLLoader.load(getClass().getResource("/view/FirstInventoryScreen.fxml"));
            Scene scene = new Scene(cancelPartAdd);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            ;
            stage.show();
        } else {
            System.out.println("You clicked cancel");
        }

    }

    /**
     * In-House radio Button - sets InHouse Machine Company Label to "Machine ID".
     *
     * @param event Caused by clicking InHouse Radio Button.
     */
    public void onInHouseRb(ActionEvent event) {
        machineCompanyLabel.setText("Machine ID");
    }

    /**
     * Out-Source radio button - sets Outsourced Machine Company Label to "Company Name".
     *
     * @param event Caused by clicking OutSourced Radio Button.
     */
    public void onOutSourcedRb(ActionEvent event) {
        machineCompanyLabel.setText("Company Name");
    }
}
