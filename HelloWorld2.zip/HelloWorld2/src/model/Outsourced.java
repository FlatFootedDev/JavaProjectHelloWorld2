package model;

/**
 * @author George Calderon
 */
public class Outsourced extends Part {
    private String companyName;

    /**
     *
     * @param id Integer
     * @param name String
     * @param price Double
     * @param stock Integer
     * @param min Integer
     * @param max Integer
     * @param companyName String
     */
    public Outsourced(int id, String name, double price, int stock, int min, int max, String companyName) {
        super(id, name, price, stock, min, max);
        this.companyName = companyName;
    }

    /**
     *
     * @param companyName String
     */
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    /**
     *
     * @return String of Name of Company
     */
    public String getCompanyName() {
        return companyName;
    }


}
