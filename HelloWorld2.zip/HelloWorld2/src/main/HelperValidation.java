package main;

import java.io.IOException;

/**
 * Provides validation method for several input parameters.
 * @author George Calderon
 */
public class HelperValidation {
    public static int getStock(String value) throws NumberFormatException {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            throw new NumberFormatException("Inventory must be a whole number between Min and Max.");
        }
    }

    /**
     * Checks if Name entered is in the form of a String.
     *
     * @param value String.
     * @return The validated Name.
     * @throws IOException Throws exception if Name is blank or not String.
     */
    public static String getName(String value) throws IOException {
        if (value.isBlank()) {
            throw new IOException("Name is required!");
        }
        return value;
    }

    /**
     * Check if Price is a numerical number in decimal form.
     *
     * @param value Decimal Number.
     * @return The validated Price.
     * @throws NumberFormatException Thrown if not in NumberFormat - decimal form.
     */
    public static double getPrice(String value) throws NumberFormatException {
        try {
            return Double.parseDouble(value);
        } catch (NumberFormatException e) {
            throw new NumberFormatException("Price must be a decimal number");
        }
    }

    /**
     * Checks Company Name.
     *
     * @param value String to be validated(representing the company name).
     * @return The validated Company Name.
     * @throws IOException Thrown id Company Name is blank or not String.
     */
    public static String getCompanyName(String value) throws IOException {
        if (value.isBlank()) {
            throw new IOException("Company Name is Required!");
        }
        return value;
    }

    /**
     * Checks Max Number.
     *
     * @param value Expected Numeric string representing an integer value.
     * @return The validated Max Value.
     * @throws NumberFormatException If not a whole number or an integer value.
     */
    public static int getMaxNum(String value) throws NumberFormatException {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            throw new NumberFormatException("Max must be a whole number higher than Min!");
        }
    }

    /**
     * Checks Min Number.
     *
     * @param value Value less than Max.
     * @return The validated Min Value.
     * @throws NumberFormatException If not a whole number or an integer value.
     */
    public static int getMinNum(String value) throws NumberFormatException {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            throw new NumberFormatException("Min must be a whole number higher than Max!");
        }
    }

    /**
     * Checks Min and Max Whole numbers entered.
     *
     * @param min   Min whole number less than Max.
     * @param max   Max whole number greater than Min.
     * @param stock Whole number between Min and Max.
     * @throws NumberFormatException Thrown is Min number is less than Max and Stock is not whole number between Min and Max.
     */
    public static void validateMinMaxStock(int min, int max, int stock) throws NumberFormatException {
        if (min > max || min > stock || stock > max) {
            throw new NumberFormatException("Min must be < Max and Stock must be a number between Min and Max!");
        }

    }

    /**
     * Check if whole number is entered and not String.
     *
     * @param value String value representing the MachineID.
     * @return The validated value or machineID.
     * @throws NumberFormatException Thrown if not entered as whole number or integer value.
     */
    public static int getMachineID(String value) throws NumberFormatException {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            throw new NumberFormatException("Machine ID must be a number");
        }
    }
}
