package main;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import model.InHouse;
import model.Inventory;
import model.Outsourced;
import model.Product;

/**
 * Main class of the application. <p>
 * FUTURE ENHANCEMENT: Make it more clear for the user when Modifying a Product/Part.<p>
 * Use a single table when modifying, instead of two.<p>
 * JAVADOC is located in folder JAVADOC within Project.
 *
 * @author George Calderon
 **/

public class Main extends Application {

    /**
     * Starts the Graphical User Interface.
     * RUNTIME ERROR: Corrected path to the form from "ew/FirstInventoryScreen.fxml" to "view/FirstInventoryScreen.fxml".
     *
     * @param stage FirstInventoryScreen
     * @throws Exception If does not load page.
     */
    @Override
    public void start(Stage stage) throws Exception {


        Parent root = FXMLLoader.load(getClass().getResource("/view/FirstInventoryScreen.fxml"));
        stage.setTitle("Inventory Management Program");
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }

    /**
     * Test Data for both Products and Parts.
     *
     * @param args Input Arguments into program.
     */
    public static void main(String[] args) {
        //test data here---

        InHouse inHouse = new InHouse(Inventory.getPartID(), "Wheel", 5.99, 5, 2, 200, 526);
        Outsourced outsourced = new Outsourced(Inventory.getPartID(), "Chain", 10.99, 9, 7, 10, "ACME TOOLS");


        Product product1 = new Product(Inventory.getProductID(), "Huffy", 100.00, 5, 2, 10);
        Product product2 = new Product(Inventory.getProductID(), "Cheapo", 50.00, 8, 7, 10);


        Inventory.addPart(inHouse);
        Inventory.addPart(outsourced);
        Inventory.addProduct(product1);
        Inventory.addProduct(product2);

        launch(args);

    }


}
