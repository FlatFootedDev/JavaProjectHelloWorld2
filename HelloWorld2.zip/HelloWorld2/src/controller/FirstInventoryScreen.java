package controller;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Inventory;
import model.Part;
import model.Product;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * @author George Calderon
 */
public class FirstInventoryScreen implements Initializable {

    public TextField searchPartText;
    public TextField searchProductText;
    public TableView<Part> partsTable;
    public TableColumn partIDColumn;
    public TableColumn partNameColumn;
    public TableColumn partInventoryColumn;
    public TableColumn partCostColumn;
    public TableView<Product> productTable;
    public TableColumn productIDColumn;
    public TableColumn productNameColumn;
    public TableColumn productInventoryColumn;
    public TableColumn productCostColumn;

    /**
     * Initializes FirstInventoryScreen Controller class.
     * @param url NOT USED
     * @param resourceBundle NOT USED
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        partsTable.setItems(Inventory.getAllParts());
        partIDColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        partNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        partInventoryColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        partCostColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        productTable.setItems(Inventory.getAllProducts());
        productIDColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        productNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        productInventoryColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        productCostColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

    }

    /**
     * Searches a Part by ID or partial name.
     * @param actionEvent The Event caused by hitting the enter key in the search field.
     */
    public void onSearchPart(ActionEvent actionEvent) {
        //check if empty

        String searchItem = searchPartText.getText();
        if (searchItem.isBlank()) {
            partsTable.setItems(Inventory.getAllParts());
            return;
        }
        // search by ID
        try {
            Part part = Inventory.lookupPart(Integer.parseInt(searchItem));
            if (part == null) {

                throw new NumberFormatException();
            }
            //Highlights the found part--
            partsTable.getSelectionModel().select(part);
        } catch (NumberFormatException e) {
            //Search by name if not found by ID
            ObservableList<Part> list = Inventory.lookupPart(searchItem);
            if (list.size() > 0) {
                partsTable.setItems(list);
            } else {
                //Alert Box when no matches are found
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("PART SEARCHED");
                alert.setContentText("No Matches Found!");
                alert.show();

            }
        }


    }

    /**
     * Searches by Product ID or partial name.
     * @param event The Event caused by hitting the enter hey in the search field.
     */
    public void onSearchProduct(ActionEvent event) {

        String searchItem = searchProductText.getText();
        if (searchItem.isBlank()) {
            productTable.setItems(Inventory.getAllProducts());
            return;
        }
        // Searches by ID
        try {
            Product product = Inventory.lookupProduct(Integer.parseInt(searchItem));
            if (product == null) {
                throw new NumberFormatException();
            }
            //Highlights the found part--
            productTable.getSelectionModel().select(product);
        } catch (NumberFormatException e) {
            //Searches by name if not found by ID
            ObservableList<Product> list = Inventory.lookupProduct(searchItem);
            if (list.size() > 0) {
                productTable.setItems(list);
            } else {
                //Alert Box when no matches are found
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("PRODUCT SEARCHED");
                alert.setHeaderText("No Matches Found!");
                alert.show();
            }
        }

    }

    /**
     * Adds part to table.
     * @param actionEvent The Event caused by pressing the Add button on the Parts Table.
     */
    @FXML
    public void onAddPart(ActionEvent actionEvent) {
        //When clicked goes to next screen - add part screen
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/view/AddPartScreen.fxml"));
            Stage stage = (Stage) partsTable.getScene().getWindow();
            stage.setTitle("Add Part");
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Error loading Add Part Form\n " + e.getMessage());
            alert.show();
        }


    }

    /**
     * Modifies existing Part.
     * @param actionEvent  The Event when the Modify Part button is pressed by user.
     */
    public void onModifyPart(ActionEvent actionEvent) {
        try {

            Part part = partsTable.getSelectionModel().getSelectedItem();
            if (part == null){
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Modify Part");
                alert.setContentText("No part was selected. Please try again.");
                alert.show();
                return;
            }

            ModifyPartScreen.recievedPart(part);

            Parent root = FXMLLoader.load(getClass().getResource("/view/ModifyPartScreen.fxml"));
            Stage stage = (Stage) partsTable.getScene().getWindow();
            stage.setTitle("Add Part");
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Modify Part");
            alert.setContentText("Error Loading Modify Part Form. Please Try Again.");
            alert.show();

        }

    }

    /**
     * Function that will delete part selected.
     * @param actionEvent When pressed will delete selected part.
     */
    public void onPartDelete(ActionEvent actionEvent) {


        Part part = partsTable.getSelectionModel().getSelectedItem();
        if (part == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Delete Part");
            alert.setContentText("Please select a part to Delete");
            alert.show();
            return;

        }
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Delete Part");
        alert.setContentText("Please confirm that you want to delete part " + part.getName() + "?");
        Optional<ButtonType> deleteConfirmed = alert.showAndWait();
        if (deleteConfirmed.get() == ButtonType.OK) {
            Inventory.getAllParts().remove(part);
        } else {
            return;

        }

    }

    /**
     * Sends user to AddProduct Screen.
     * @param actionEvent Action Event when pressed sends user to AddProductScreen.
     */
    public void onAddProduct(ActionEvent actionEvent) {

        try {
            Parent root = FXMLLoader.load(getClass().getResource("/view/AddProductScreen.fxml"));
            Stage stage = (Stage) productTable.getScene().getWindow();
            stage.setTitle("Add Product");
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Delete Part");
            alert.setContentText("Please select a part to Delete");
            alert.show();
        }

    }

    /**
     * Sends user to ModifyProduct Screen.
     * @param actionEvent Action Event - when Modify button pressed - sends user to ModifyProduct Screen.
     */
    public void onModifyProduct(ActionEvent actionEvent) {

       try {
           Product product = productTable.getSelectionModel().getSelectedItem();
           if (product == null){
               Alert alert = new Alert(Alert.AlertType.ERROR);
               alert.setTitle("Modify Product");
               alert.setContentText("No product was selected. Please try again.");
               alert.show();
               return;
           }

           ModifyProductScreen.recievedProduct(product);

           Parent root = FXMLLoader.load(getClass().getResource("/view/ModifyProductScreen.fxml"));
           Stage stage = (Stage) productTable.getScene().getWindow();
           stage.setTitle("Modify Product");
           Scene scene = new Scene(root);
           stage.setScene(scene);
           stage.show();
       } catch (IOException e) {
           e.printStackTrace();
           Alert alert = new Alert((Alert.AlertType.ERROR));
           alert.setTitle("Modify Part");
           alert.setContentText("Please select a product to Modify");
           alert.show();
       }
    }

    /**
     * Deletes selected Product.
     * @param actionEvent Delete selected product when pressed.
     */
    public void onDeleteProduct(ActionEvent actionEvent) {
        Product product = productTable.getSelectionModel().getSelectedItem();
        if (product == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Delete Product");
            alert.setContentText("Please select a product to Delete");
            alert.show();
            return;

        }

        if (product.getAllAssociatedParts().size() > 0){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Delete Product");
            alert.setContentText("Product cannot be deleted as product has associated parts");
            alert.show();
            return;

        }


        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Delete Product");
        alert.setContentText("Please confirm that you want to delete product " + product.getName() + "?");
        Optional<ButtonType> deleteConfirmed = alert.showAndWait();
        if (deleteConfirmed.get() == ButtonType.OK) {
            Inventory.getAllProducts().remove(product);
        } else {
            return;

        }

    }

    /**
     * Quits Program.
     * @param event When pressed will quit program and exit.
     */
    public void onExit(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);

        alert.initModality(Modality.NONE);
        alert.setTitle("Quit");
        alert.setHeaderText("Would you like to Quit Program?");
        Optional<ButtonType> exit = alert.showAndWait();
        if (exit.get() == ButtonType.OK) {
            System.exit(0);
        } else {
            System.out.println("Cancel");
        }


    }

}
