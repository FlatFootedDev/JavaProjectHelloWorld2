package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import main.HelperValidation;
import model.Inventory;
import model.Part;
import model.Product;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * Controller that Manages AddProduct Form.
 *
 * @author George Calderon
 */
public class AddProductScreen implements Initializable {

    public TextField productIDTextField;
    public TextField nameTextField;
    public TextField inventoryTextField;
    public TextField minTextField;
    public TextField priceCostTextField;
    public TextField maxTextField;
    public TableView<Part> partsTable;
    public TableColumn partIdCol;
    public TableColumn partNameCol;
    public TableColumn partInvCol;
    public TableColumn partPriceCol;
    public TableView<Part> associatedPartsTable;
    public TableColumn associatedPartIdCol;
    public TableColumn associatedPartNameCol;
    public TableColumn associatedPartInvCol;
    public TableColumn associatedPartPriceCol;
    public TextField partSearch;
    public TextField searchTextField;
    private ObservableList<Part> associateParts = FXCollections.observableArrayList();

    /**
     * Initializes the AddProduct controller class.
     * @param location NOT USED
     * @param resources NOT USED
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {

        partsTable.setItems(Inventory.getAllParts());
        partIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        partNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        partInvCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        partPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));

        associatedPartsTable.setItems(associateParts);
        associatedPartIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        associatedPartNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        associatedPartInvCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        associatedPartPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));


    }

    /**
     * Cancel - Returns to the current form.
     * @param event When Cancel button is pressed - Returns to the current form.
     * @throws IOException - Thrown when there is an error loading the form.
     */
    public void onCancel(ActionEvent event) throws IOException {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.initModality(Modality.NONE);
        alert.setTitle("Add Part Exit");
        alert.setContentText("Would You Like to Cancel");
        Optional<ButtonType> cancel = alert.showAndWait();

        if (cancel.get() == ButtonType.OK) {
            Parent cancelPartAdd = FXMLLoader.load(getClass().getResource("/view/FirstInventoryScreen.fxml"));
            Scene scene = new Scene(cancelPartAdd);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            ;
            stage.show();
        } else {
            System.out.println("You clicked cancel");
        }

    }

    /**
     * Saves new Product.
     * @param event Caused by clicking the save button on the form.
     */
    public void onSave(ActionEvent event) {
        try {


            int min = HelperValidation.getMinNum(minTextField.getText());
            int max = HelperValidation.getMaxNum(maxTextField.getText());
            double price = HelperValidation.getPrice(priceCostTextField.getText());
            String name = HelperValidation.getName(nameTextField.getText());
            int inv = HelperValidation.getStock(inventoryTextField.getText());
            HelperValidation.validateMinMaxStock(min, max, inv);
            Product product = new Product(Inventory.getProductID(), name, price, inv, min, max);
            for (Part part:associateParts) {
                product.addAssociatedPart(part);
            }
            Inventory.addProduct(product);

            Parent root = FXMLLoader.load(getClass().getResource("/view/FirstInventoryScreen.fxml"));
            Stage stage = (Stage) nameTextField.getScene().getWindow();
            stage.setTitle("Inventory Management Program");
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();

        } catch (NumberFormatException | IOException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Add Part Error");
            alert.setContentText(e.getMessage());
            alert.show();
            return;
        }
    }

    /**
     * Removes Associated Part on the selected table.
     * @param event Removes associated Part after highlighted on table and associated button pressed.
     */
    public void onRemove(ActionEvent event) {
        Part part = associatedPartsTable.getSelectionModel().getSelectedItem();

        if (part != null) {
            associateParts.remove(part);
        } else {
            Alert noPartSelected = new Alert(Alert.AlertType.ERROR);
            noPartSelected.setContentText("No Part Selected.\n Please try again.");
            noPartSelected.show();
        }
    }

    /**
     * Adds Associated Part.
     * @param event Caused when associated "Add" button is pressed - adding Part to PartsTable.
     */
    public void onAdd(ActionEvent event) {
        Part part = partsTable.getSelectionModel().getSelectedItem();

        if (part != null) {
            associateParts.add(part);
        } else {
            Alert noPartSelected = new Alert(Alert.AlertType.ERROR);
            noPartSelected.setContentText("No Part Selected.\n Please try again.");
            noPartSelected.show();
        }

    }

    /**
     * Searches by Product ID or Partial Product Name.
     * @param event Event caused by hitting the Enter Key in the Search Field.
     */
    public void onSearch(ActionEvent event) {
        String searchItem = searchTextField.getText();
        if (searchItem.isBlank()) {
            partsTable.setItems(Inventory.getAllParts());
            return;
        }
        // search by ID
        try {
            Part part = Inventory.lookupPart(Integer.parseInt(searchItem));
            if (part == null) {

                throw new NumberFormatException();
            }
            //Highlights the found part--
            partsTable.getSelectionModel().select(part);
        } catch (NumberFormatException e) {
            //Search by name if not found by ID
            ObservableList<Part> list = Inventory.lookupPart(searchItem);
            if (list.size() > 0) {
                partsTable.setItems(list);
            } else {
                //Alert Box when no matches are found
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("PART SEARCHED");
                alert.setContentText("No Matches Found!");
                alert.show();

            }
        }

    }
}